export const TESTIMONIALS = [
  {
    quote: 'The coziest spot in town! Their hot coffee tastes like a warm hug. Always my go-to café after work.',
    author: 'Riya S.'
  },
  {
    quote: 'Love the vibe here. The interiors are calm and inviting, and the French fries are the crispiest I’ve ever had!',
    author: 'Arjun M.'
  },
  {
    quote: 'A perfect balance of good food, good coffee, and good people. Cozy Corner feels like home.',
    author: 'Meera T.'
  },
  {
    quote: 'Their chicken lollipops and noodles are just amazing. A hidden gem in the city.',
    author: 'Rahul K.'
  }
]


